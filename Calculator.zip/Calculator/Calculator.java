package Calculator;

public class Calculator {
    double operandOne;
    double operandTwo;
    String setOperation;
    double calculate;

    public Calculator() {
        operandOne = 0;
        operandTwo = 0;
        setOperation = " ";
        calculate = 0;
    }

    public void setOperandOne(double OPone) {
        operandOne = OPone;
    }

    public void setOperandTwo(double OPtwo) {
        operandTwo = OPtwo;
    }

    public void setOp(String OP) {
        setOperation = OP;
    }

    public void calculate() {
        if (setOperation == "+") {
            calculate = operandOne + operandTwo;
        }
        if (setOperation == "-") {
            calculate = operandOne - operandTwo;
        }
    }

    public void calculate(double Op1, double Op2, String newOP) {
        setOp(newOP);
        setOperandOne(Op1);
        setOperandTwo(Op2);
        if (setOperation == "+") {
            calculate = operandOne + operandTwo;
        }
        if (setOperation == "-") {
            calculate = operandOne - operandTwo;
        }
    }

    public double results(){
        double result = calculate;
        System.out.println(result);
        return result;
    }
}
