package Calculator;

public class CalculatorTest {
    public static void main(String[] args) {
        Calculator calculate = new Calculator();
        calculate.setOperandOne(8.2);
        calculate.setOperandTwo(13.6);
        calculate.setOp("+");
        calculate.calculate();
        calculate.results();
        System.out.println(calculate.calculate);
    }
}
