package ProjectClass;

public class ProjectClass {
    String name;
    String description;


    public ProjectClass() {
    }
    

    public ProjectClass(String NewName) {
        this.name = NewName;
    }


    public ProjectClass(String Newname, String NewDescription) {
        this.name = Newname;
        this.description = NewDescription;
    }

    public void elevatorPitch(ProjectClass anotherObject) {
        System.out.println(this.name + " : " + this.description);
    }

    
}
