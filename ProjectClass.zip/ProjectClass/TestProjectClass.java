package ProjectClass;

public class TestProjectClass {
    public static void main(String[] args) {
        ProjectClass project1 = new ProjectClass("Test", "Your description here");
        project1.elevatorPitch(project1);
    }
}
