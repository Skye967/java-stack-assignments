public class firstJavaProgram {
    public static void main(String[]args){

        String name = "Skye";
        String age = "31";
        String from = " Haiku, Maui, Hi";

        System.out.println("My name is " + name);
        System.out.println("I am " + age + " years old");
        System.out.println("My hometown is " + from);

        }
    
}