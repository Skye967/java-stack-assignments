package Pokemon;
import java.util.ArrayList;

public class AbstractPokemon implements PokemonInterface {
    public int namecount;
    ArrayList<String> myPokemon = new ArrayList<String>();

    {
        namecount += 1;
    }

    public Pokemon createPokemon(String name, int health, String type) {
        Pokemon pokemon = new Pokemon();
        myPokemon.add(name);
        pokemon.setName(name);
        pokemon.setHealth(health);
        pokemon.setType(type);
        return pokemon;
    }
    
    public String pokemonInfo(Pokemon pokemon) {
        String info = "Pokemon Info";
        pokemon.getName();
        pokemon.getType();
        pokemon.getHealth();
        return info;
    }
    
    public void listPokemon() {
    }
}
