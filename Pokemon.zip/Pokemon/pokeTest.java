package Pokemon;

public class pokeTest {
    public static void main(String[] args) {
        Pokedex pokedex = new Pokedex();
        Pokemon pikachu = pokedex.createPokemon("pikachu", 50, "lightning");
        Pokemon charmander = pokedex.createPokemon("charmander", 60, "fire");
        Pokemon squirtel = pokedex.createPokemon("squirtle", 70, "water");

        pokedex.listPokemon();
        pokedex.pokemonInfo(pikachu);
        pikachu.attackPokemon(charmander);
        pokedex.pokemonInfo(charmander);
    }
}
