package Pokemon;

public class Pokemon{
    public String name;
    public String type;
    public int health;
    public static int count;

    public Pokemon() {
        name = "null";
        type = "null";
        health = 0;
    }

    {
        count += 1;
    }

    public void attackPokemon(Pokemon pokemon) {
        Pokemon attackedPokemon = pokemon;
        attackedPokemon.health -= 10;
    }

    public void setName(String newName) {
        name = newName;
    }

    public void getName() {
        System.out.println(name);
    }

    public void setType(String setType) {
        type = setType;
    }

    public void getType() {
        System.out.println(type);
    }

    public void setHealth(int setHealth) {
        health = setHealth;
    }

    public void getHealth() {
        System.out.println(health);
    }


    
}
