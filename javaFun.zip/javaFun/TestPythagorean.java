package javaFun;

public class TestPythagorean {

    public static void main(String[]args){
        Pythagorean iD = new Pythagorean();
        double getSquareRoot = iD.calculateHypotenuse(5, 5);
        System.out.println(getSquareRoot);

    }
    
}
