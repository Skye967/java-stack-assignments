package FizzBuzz;

public class TestFizzBuzz {
    public static void main(String[]args){
        FizzBuzz iD = new FizzBuzz();
        String getFizzBuzz = iD.fizzBuzz(2);
        System.out.println(getFizzBuzz);

    }
}
