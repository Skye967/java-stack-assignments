package FizzBuzz;

public class FizzBuzz {
    public String fizzBuzz(int number) {
        // fizzbuzz logic here
        int outNumber = number;
        String fizzBuzz = "";
        if (outNumber == 3) {
            fizzBuzz = "Fizz";
        }
        if (outNumber == 5) {
            fizzBuzz = "Buzz";
        }
        if (outNumber == 15) {
            fizzBuzz = "FizzBuzz";
        }
        if (outNumber == 2) {
            fizzBuzz = "2";
        }
        return fizzBuzz;
    }
}
