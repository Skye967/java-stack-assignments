package Phone;

public class PhoneTest {
    public static void main(String[] args) {
        Galaxy A = new Galaxy(1, 100, "Shrek", "Shut up donkey!");
        Iphone B = new Iphone(007, 302, "Crap", "Farts");

        A.displayInfo();
        B.getBatteryPercentage();
        A.getCarrier();
        B.getRingTone();
        A.getVersionNumber();
        B.unlock();



    }
    
}
