package Phone;

public abstract class Phone {

    private int versionNumber;
    private int batteryPercentage;
    private String carrier;
    private String ringTone;

    public Phone(int i, int batteryPercentage, String carrier, String ringTone){
        this.versionNumber = i;
        this.batteryPercentage = batteryPercentage;
        this.carrier = carrier;
        this.ringTone = ringTone;
    }
    // abstract method. This method will be implemented by the subclasses

    public abstract void displayInfo();
   
    public int getVersionNumber() {
        System.out.println(versionNumber);
		return versionNumber;

	}


	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}


    public int getBatteryPercentage() {
        System.out.println(batteryPercentage);
		return batteryPercentage;

	}


	public void setBatteryPercentage(int batteryPercentage) {
		this.batteryPercentage = batteryPercentage;
	}


    public String getCarrier() {
        System.out.println(carrier);
		return carrier;
	}


	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}


    public String getRingTone() {
        System.out.println(ringTone);
		return ringTone;
	}


	public void setRingTone(String ringTone) {
		this.ringTone = ringTone;
	}

    
    // getters and setters removed for brevity. Please implement them yourself
}

    

