package Phone;

public interface Ringable {
    
    String ring();

    String unlock();

}
