package Phone;

public class Galaxy extends Phone implements Ringable {
    public Galaxy(int i, int batteryPercentage, String carrier, String ringTone) {
        super(i, batteryPercentage, carrier, ringTone);
    }
    @Override
    public String ring() {
        System.out.println(this.getRingTone());
        return this.getRingTone();
    }
    @Override
    public String unlock() {
        System.out.pringln("Unlock Face Recondition");
    	return "Unlock Face Recondition";
    }
    @Override
    public void displayInfo() {
    	System.out.println( "Samsung" + " " + this.getVersionNumber() + " " + this.getCarrier() + " " ) ;
    }
}
