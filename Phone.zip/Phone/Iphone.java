package Phone;

public class Iphone extends Phone implements Ringable {

    public Iphone(int i, int batteryPercentage, String carrier, String ringTone) {
        super(i, batteryPercentage, carrier, ringTone);
    }

    @Override
    public String ring() {
        System.out.println(this.getRingTone());
        return this.getRingTone();

    }

    @Override
    public String unlock() {
        System.out.println("unlocked");
        return "Unlocked";

    }

    @Override
    public void displayInfo() {
        System.out.println("Iphone" + " " + this.getVersionNumber() + " " + this.getCarrier() + " ");
    }
}
