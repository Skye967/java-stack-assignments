package Trie;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.ArrayList;

import org.graalvm.compiler.word.Word;

public class Trie {
    public Node root;

    ArrayList<String> T = new ArrayList<String>();
    
    public Trie() {
        this.root = new Node();
    }


    public void printAllKeys() {
        Node keyNode = this.root;
        HashMap test = keyNode.children;
        Object currentLetter;
        Iterator arr = test.keySet().iterator();
        for (int i = 1; i > 0; i++) {
            while (arr.hasNext() != false) {
                currentLetter = arr.next();
                System.out.println(currentLetter);
                Node childKeyNode = keyNode.children.get(currentLetter);
                System.out.println(childKeyNode.children.keySet());
                keyNode = childKeyNode;
            }
        }
    }

    public void isPrefixValid(String prefix) {
        boolean isPrefixValid = true;
        Node prefixNode = this.root;
        for (int i = 0; i < prefix.length(); i++) {
            System.out.println(prefixNode);
            Character currentLetter = prefix.charAt(i);
            Node prefixChild = prefixNode.children.get(currentLetter);
            prefixNode = prefixChild;
            if (prefixChild == null) {
                isPrefixValid = false;
            }
        }
        System.out.println(isPrefixValid);
    }

    public boolean isWordValid(String word) {
        boolean isWordValid = true;
        Node wordNode = this.root;
        for (int i = 0; i < word.length(); i++) {
            // currentLetter is just the character / letter at the iteration
            Character currentLetter = word.charAt(i);
            // ask if the current letter is in the map of the current node
            Node wordChild = wordNode.children.get(currentLetter);
            wordNode = wordChild;
            if (wordChild == null) {
                isWordValid = false;
                System.out.println(isWordValid);
                return isWordValid;
            }
        }
        System.out.println(isWordValid);
        return isWordValid;
    }
    
    public void insertWord(String word) {
        // gets the root node;
        Node currentNode = this.root;
        // iterates over every character in the word
        for(int i = 0; i < word.length(); i++) {
            // currentLetter is just the character / letter at the iteration
            Character currentLetter = word.charAt(i);
            // ask if the current letter is in the map of the current node
            Node child = currentNode.children.get(currentLetter);
            if(child == null) {
                child = new Node();
                currentNode.children.put(currentLetter, child); 
            } 
            
            currentNode = child;
        }
        currentNode.isCompleteWord = true;
    }
}
