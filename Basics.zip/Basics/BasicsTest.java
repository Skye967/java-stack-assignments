package Basics;

public class BasicsTest {

    public static void main(String[] args) {
        

        Basics id1 = new Basics();
        //int printNums = id1.printNumbers();
        //System.out.println(printNums);


        Basics id2 = new Basics();
        //int printOdds = id2.printOddNumbers();
        //System.out.println(printOdds);



        Basics id3 = new Basics();
        //int printSum = id3.printSumNumbers();
        //System.out.println(printSum);



        Basics id4 = new Basics();
        int[] arr;
        arr = new int[5];
        arr[0] = 11;
        arr[1] = 12;
        arr[2] = 13;
        arr[3] = 14;
        arr[4] = 15;
        //int printArrNums = id4.iterateArray(arr);
        //System.out.println(printArrNums);



        Basics id5 = new Basics();
        int printMaxArrNum = id5.MaxArrayNum(arr);
        //System.out.println(printMaxArrNum);


        Basics id6 = new Basics();
        int printAverageArrNum = id6.AverageArrayNum(arr);
        //System.out.println(printAverageArrNum);


        Basics id7 = new Basics();
        Object printOddNumArr = id7.oddNumArr();
        //System.out.println(printOddNumArr);


        Basics id8 = new Basics();
        int greatNum = id8.greaterThan(arr, 12);
        //System.out.println(greatNum);


        Basics id9 = new Basics();
        Object SquaredArr = id9.SquareValues(arr);
        //System.out.println(SquaredArr);


        Basics id10 = new Basics();
        Object mmaa = id10.MaxMinAvg(arr);
        //System.out.println(mmaa);


        Basics id11 = new Basics();
        Object ShiftedArr = id11.shiftArrValues(arr);
        System.out.println(ShiftedArr);
    }
    
}
