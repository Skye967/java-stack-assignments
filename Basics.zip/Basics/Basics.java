package Basics;
import java.util.ArrayList;
public class Basics {

    int printNumbers() {
        int buff = 0;
        for (int i = 0; i <= 255; i++) {
            System.out.println(i);
        }
        return buff;
    }



    int printOddNumbers() {
        int buff2 = 1;
        for (int i = 0; i <= 255; i++) {
            if (i % 2 != 0) {
                System.out.println(i);
            }
        }
        return buff2;
    }
    

    int printSumNumbers() {
        int sum = 0;
        for (int i = 0; i <= 255; i++) {
            sum += i;
        }
        return sum;
    }


    int iterateArray(int[] arr) {
        int buff3 = 0;
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
        return buff3;
    }


    int MaxArrayNum(int[] arr) {
        int Max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > Max) {
                Max = arr[i];
            }
        }
        return Max;
    }


    int AverageArrayNum(int[] arr) {
        int Sum = 0;
        for (int i = 0; i < arr.length; i++) {
            Sum += arr[i];
        }
        int Average = Sum / arr.length;
        return Average;
    }


    
    Object oddNumArr() {
        ArrayList<Integer> myArray = new ArrayList<Integer>();
        for (int i = 0; i <= 255; i++) {
            if (i % 2 != 0) {
                myArray.add(i);
            }
        }
        return myArray;
    }



    int greaterThan(int[] arr, int Great) {
        int greater = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > Great) {
                greater++;
            }
        }
        return greater;
    }

    Object SquareValues(int[] arr) {
        ArrayList<Integer> squaredArr = new ArrayList<Integer>();
        for (int i = 0; i < arr.length; i++) {
            squaredArr.add(arr[i] * arr[i]);
        }
        return squaredArr;
    }


    Object MaxMinAvg(int[] arr) {
        ArrayList<Integer> MMAarr = new ArrayList<Integer>();
        int max = 0;
        int min = arr[0];
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        int avg = sum / arr.length;
        MMAarr.add(max);
        MMAarr.add(min);
        MMAarr.add(avg);
        return MMAarr;
    }



    Object shiftArrValues(int[] arr) {
        ArrayList<Integer> shiftedArr = new ArrayList<Integer>();
        for (int i = 0; i < arr.length - 1; i++) {
            shiftedArr.add(arr[i + 1]);
        }
        shiftedArr.add(0);
        return shiftedArr;
    }
}
