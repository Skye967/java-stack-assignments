package ZooKeeper.ZooKeeperTest;

import ZooKeeper.gorilla;

public class gorillaTest {
    
    public static void main(String[] args) {
        gorilla newGorilla = new gorilla();
        newGorilla.eatBananas();
        newGorilla.throwSomthing();
        newGorilla.climb();
        newGorilla.displayEnergy();
        
        
    }
}
