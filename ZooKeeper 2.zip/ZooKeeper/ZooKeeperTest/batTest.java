package ZooKeeper.ZooKeeperTest;
import ZooKeeper.Bat;
public class batTest {
    public static void main(String[] args) {
        Bat newBat = new Bat();
        newBat.eatHumans();
        newBat.fly();
        newBat.attackTown();
        newBat.displayEnergy();

    }
}
