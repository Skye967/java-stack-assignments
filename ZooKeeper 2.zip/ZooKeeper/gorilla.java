package ZooKeeper;

 public class gorilla extends mammal {
        
        public gorilla(){
        energyLevel = 100;
        }

        public String throwSomthing() {
            String something = "The Gorilla threw something!";
            System.out.println(something);
            energyLevel -= 5;
            return something;
        }

        public String eatBananas() {
            String eat = "The Gorilla is eating bananas.";
            System.out.println(eat);
            energyLevel += 10;
            return eat;
        }

        public String climb() {
            String climbing = "The Gorilla is climbing a tree.";
            System.out.println(climbing);
            energyLevel -= 10;
            return climbing;
        }
        

    }
