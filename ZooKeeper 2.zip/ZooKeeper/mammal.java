package ZooKeeper;

 class mammal {

    protected int energyLevel;

    public int displayEnergy() {
        System.out.println(energyLevel);
        return energyLevel;
    }
}