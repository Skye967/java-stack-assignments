package ZooKeeper;

public class Bat extends mammal {
    
    public Bat(){
        energyLevel = 300;
    }
    

    public String fly() {
        String sound = "Fwoop fwoop fwoop fwoop";
        energyLevel -= 50;
        System.out.println(sound);
        return sound;
    }

    public String eatHumans() {
        String yummy = "so- well, never mind";
        energyLevel += 25;
        System.out.println(yummy);
        return yummy;
    }

    public String attackTown() {
        String attack = "People Screaming, and running. Cars Crashing, and Blood in the streets.";
        energyLevel -= 100;
        System.out.println(attack);
        return attack;
    }
    
}
