package BankAccount;


public class BankAccountTest {

    public static long AllTotal() {
        long totalNum = BankAccount.totalAll();
        System.out.println(totalNum);
        return totalNum;
    }
    
    public static int AcountCount() {
        int totalCount = BankAccount.howMany();
        System.out.println(totalCount);
        return totalCount;
    } 
    
    public static void main(String[] args) {
        BankAccount user1 = new BankAccount();
        BankAccount user2 = new BankAccount();
        user2.deposit("savings", 3000);
        user1.deposit("checking", 1000.00);
        user1.getCheckingBalance();
        user2.getSavingsBalance();
        AllTotal();
        AcountCount();
        System.out.println(user1.accountNumber);
    }
}
