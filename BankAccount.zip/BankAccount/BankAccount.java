package BankAccount;

public class BankAccount {
    public String accountNumber;
    public double checkingBalance;
    public double savingsBalance;
    public static int count = 0;
    public static long totalAllAccounts;

    {
        count += 1;
    }

    {
        totalAllAccounts = 0;
    }

    public static long totalAll() {
        long TAA = totalAllAccounts;
        return TAA;
    }

    public BankAccount() {
        gen();
    }

    public static int howMany() {
        int number = count;
        return number;
    }

    private String gen() {
        long num = Math.round(Math.random() * (99999999 - 10000000) + 10000000);
        accountNumber = String.valueOf(num);
        return accountNumber;
    }   

    

    public void getCheckingBalance() {
        System.out.println(checkingBalance);
    }

    public void getSavingsBalance() {
        System.out.println(savingsBalance);
    }

    public void deposit(String type, double amount) {
        if (type == "checking") {
            checkingBalance += amount;
            totalAllAccounts += amount;
        }
        if (type == "savings") {
            savingsBalance += amount;
            totalAllAccounts += amount;
        }
    }

    public void withdrawl(String type, double amount) {
        if (type == "checking" && checkingBalance != 0) {
            checkingBalance -= amount;
            totalAllAccounts -= amount;
        }
        if (type == "savings" && savingsBalance != 0) {
            savingsBalance -= amount;
            totalAllAccounts -= amount;
        }
    }

    public void total() {
        double total = savingsBalance + checkingBalance;
        System.out.println(total);
    }

    
}

 