package mapHashmatique;

import java.util.HashMap;
import java.util.Set;

public class mapHashmatique {
    public static void main(String[]args){
        
    HashMap<String, String> tracklist = new HashMap<String, String>();
    tracklist.put("test", "Looking for some words");
    tracklist.put("Unreal", "Crazy song lyrics");
    tracklist.put("Trying", "Not very good at remembering songs");
    tracklist.put("Last", "Last song lyrics");

        System.out.println(tracklist.get("test"));
        
        Set<String> keys = tracklist.keySet();

        for (String key : keys) {
            System.out.println(key);
            System.out.println(tracklist.get(key));
        }

    }
    
}
