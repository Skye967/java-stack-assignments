package DoubleLinkedList;

public class DLL {
    public Node head;
    public Node tail;
    public int nodeCount;
    
    public DLL() {
        this.head = null;
        this.tail = null;
    }
    
    

    public void list() {
        System.out.println(nodeCount);
    }

    // the push method will add a new node to the end of the list
    public void push(Node newNode) {
        nodeCount += 1;
        // if there is no head in the list, aka, an empty list, we set the newNode to be the head and tail of the list
        if (this.head == null) {
            this.head = newNode;
            this.tail = newNode;
            return;
        }
        // first find the lastNode in the list
        // then, set the lastNode's next to be the newNode;
        // then, we have to set the previous of the lastNode to the lastNode that we found previously.
        // finally, set the list's tail to be the node that we have added
        Node lastNode = this.tail;
        lastNode.next = newNode;
        newNode.previous = lastNode;
        this.tail = newNode;
    }
    
    public Node pop() {
        Node currentTail = this.tail;
        if (this.tail != null) {
            this.tail = this.tail.previous;
            System.out.println(currentTail.value);
        }
        return currentTail;
    }
    
    public void contains(int theValue) {
        int current = this.head.value;
        boolean here = false;
        while (current != 0) {
            if (current == theValue) {
                here = true;
                break;
            } else {
                current = this.head.next.value;
            }
        }
        System.out.println(here);
    }
    
    public void printValuesForward() {
        // find the first node, aka head.
        Node current = this.head;

        // while the current node exists...
        while (current != null) {
            // print it's value
            System.out.println(current.value);
            // and move on to it's next node.
            current = current.next;
        }
        System.out.println("end");
    }
    
    public void printValuesBackwards() {
        Node Last = this.tail;
        while (Last != null) {
            System.out.println(Last.value);
            Last = Last.previous;
        }
        System.out.println("end");
    }
}
