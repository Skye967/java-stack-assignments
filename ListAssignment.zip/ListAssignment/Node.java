package ListAssignment;

public class Node {
    public int value;
    public Node next;

    public Node(int value) {
        // your code here
        this.value = value;
        this.next = null;
    }
    
    public int getData(){
        return this.value;
    }
    public void setNext(Node next){
        this.next = next;
    }
    public Node getNext(){
        return this.next;
    }

}
