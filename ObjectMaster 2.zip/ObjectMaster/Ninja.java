package ObjectMaster;

public class Ninja extends Human{
    public Ninja() {
        stealth = 10;
    }

    public void stealHuman(Human human) {
        Human stolenHealth = human;
        stolenHealth.health -= stealth;
        health += stealth;
        System.out.println(stolenHealth.health);
        System.out.println(health);
    }

    public void runAway() {
        health -= 10;
        System.out.println(health);
    }
    
}
