package ObjectMaster;


public class Samurai extends Human {
    static int count = 0;

    {
        count += 1;
    }

    public int howMany(){
        int number = count;
        System.out.println(number);
        return number;
    }

    public Samurai() {
        health = 200;
        System.out.println(health);
    }

    public void deathBlow(Human human) {
        Human deadHuman = human;
        deadHuman.health = 0;
        health /= 2;
        System.out.println(deadHuman.health);
        System.out.println(health);
    }
    
    public void meditate() {
        health += health / 2;
        System.out.println(health);
    }
}
