package ObjectMaster;

public class Wizzard extends Human {
    public Wizzard() {
        health = 50;
        intelligence = 8;
    }

    public void heal(Human human) {
        Human healingHuman = human;
        healingHuman.health += intelligence;
        System.out.println(healingHuman.health);
    }
    
    public void fireball(Human human) {
        Human burnHuman = human;
        burnHuman.health -= intelligence * 3;
        System.out.println(burnHuman.health);
    }


}
