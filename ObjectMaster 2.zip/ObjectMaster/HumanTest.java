package ObjectMaster;

public class HumanTest {
    public static void main(String[] args) {
        Human A = new Human();
        Human B = new Human();
        Wizzard gandalf = new Wizzard();
        Ninja naruto = new Ninja();
        Samurai musashi = new Samurai();
        A.attack(B);
        gandalf.fireball(A);
        naruto.stealHuman(gandalf);
        musashi.deathBlow(naruto);
        System.out.println("something");
    }
}
