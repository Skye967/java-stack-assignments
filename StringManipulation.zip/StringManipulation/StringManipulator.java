package StringManipulation;

public class StringManipulator {
    
    String trimAndConcat(String A, String B) {
        String AB = A.trim().concat(B.trim());
        return AB;
    }


    Integer getIndexOrNull(String A2, char B2) {
        int indexOrNumll = A2.indexOf(B2);
        return indexOrNumll;
    }
    

    Integer getIndexOrNull2(String A3, String B3) {
        int indexOrNumll = A3.indexOf(B3);
        return indexOrNumll;
    }
    

    String concatSubstring(String A4, int B4, int C4, String D4){
        String theConcatSubstring = A4.substring(B4, C4) + D4;
        return theConcatSubstring;
    }
    
}
