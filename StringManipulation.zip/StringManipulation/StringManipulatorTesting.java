package StringManipulation;

public class StringManipulatorTesting {
    public static void main(String[] args) {
        
        StringManipulator id1 = new StringManipulator();
        String getTrimAndConcat = id1.trimAndConcat("   Holy  ", "  cow  ");
        System.out.println(getTrimAndConcat);


        StringManipulator id2 = new StringManipulator();
        int ofIndexOrNull = id2.getIndexOrNull("Putting a string here", 's');
        System.out.println(ofIndexOrNull);


        StringManipulator id3 = new StringManipulator();
        int ofIndexOrNull2 = id3.getIndexOrNull2("Putting a string here", "here");
        System.out.println(ofIndexOrNull2);


        StringManipulator id4 = new StringManipulator();
        String getConcatSub = id4.concatSubstring("Hello my freaky darling", 9, 15, " Alien");
        System.out.println(getConcatSub);
    }
}
